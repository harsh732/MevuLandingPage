<?php
     $dbhost = 'mevudb.cfqgvyhpo6wh.us-east-1.rds.amazonaws.com:3306';
     $dbuser = 'root';
     $dbpass = 'mevuplay';
     $dbname = 'mevu';
    $name=$_POST['name'];
    $email=$_POST['email'];

   $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   if(! $conn )
   {
     die('Could not connect: ' . mysql_error());
   }
   echo 'Connected successfully';
    $sql = "INSERT INTO mevu.users (name,email)
VALUES ('$name','$email')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
   mysqli_close($conn);
header('Location: index.html');
?>